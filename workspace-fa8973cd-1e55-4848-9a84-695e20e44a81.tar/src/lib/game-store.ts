import { create } from 'zustand'

export type GameScreen = 
  | 'start' 
  | 'setup' 
  | 'word-reveal' 
  | 'timer' 
  | 'voting' 
  | 'results'
  | 'how-to-play'

export interface Player {
  id: number
  name: string
  isImpostor: boolean
  word?: string
  hasSeenWord: boolean
  votes: number
}

export interface GameCategory {
  id: string
  name: string
  words: string[]
}

export interface GameState {
  screen: GameScreen
  players: Player[]
  currentPlayerIndex: number
  secretWord: string
  timerDuration: number
  timeRemaining: number
  isDarkMode: boolean
  selectedCategory: string
  showHowToPlay: boolean
  
  // Actions
  setScreen: (screen: GameScreen) => void
  setPlayers: (count: number) => void
  setImpostorCount: (count: number) => void
  startGame: (categories: GameCategory[]) => void
  revealWord: () => void
  nextPlayer: () => void
  setTimerDuration: (seconds: number) => void
  decrementTimer: () => void
  vote: (playerId: number) => void
  resetGame: () => void
  toggleDarkMode: () => void
  setCategory: (categoryId: string) => void
  setShowHowToPlay: (show: boolean) => void
}

export const useGameStore = create<GameState>((set, get) => ({
  screen: 'start',
  players: [],
  currentPlayerIndex: 0,
  secretWord: '',
  timerDuration: 120,
  timeRemaining: 120,
  isDarkMode: false,
  selectedCategory: 'all',
  showHowToPlay: false,
  
  setScreen: (screen) => set({ screen }),
  
  setPlayers: (count) => {
    const players: Player[] = Array.from({ length: count }, (_, i) => ({
      id: i + 1,
      name: `მოთამაშე ${i + 1}`,
      isImpostor: false,
      hasSeenWord: false,
      votes: 0
    }))
    set({ players })
  },
  
  setImpostorCount: (count) => {
    const { players } = get()
    if (players.length === 0) return
    
    // Reset all players
    const resetPlayers = players.map(p => ({ ...p, isImpostor: false }))
    
    // Randomly select impostors
    const impostorIndices: number[] = []
    while (impostorIndices.length < count && impostorIndices.length < players.length - 1) {
      const idx = Math.floor(Math.random() * players.length)
      if (!impostorIndices.includes(idx)) {
        impostorIndices.push(idx)
      }
    }
    
    const updatedPlayers = resetPlayers.map((p, i) => ({
      ...p,
      isImpostor: impostorIndices.includes(i)
    }))
    
    set({ players: updatedPlayers })
  },
  
  startGame: (categories) => {
    const { players, selectedCategory } = get()
    
    // Select random category and word
    let availableCategories = categories
    if (selectedCategory !== 'all') {
      availableCategories = categories.filter(c => c.id === selectedCategory)
    }
    
    const category = availableCategories[Math.floor(Math.random() * availableCategories.length)]
    const word = category.words[Math.floor(Math.random() * category.words.length)]
    
    // Assign impostors randomly
    const impostorCount = Math.max(1, Math.floor(players.length / 4))
    const impostorIndices: number[] = []
    while (impostorIndices.length < impostorCount && impostorIndices.length < players.length - 1) {
      const idx = Math.floor(Math.random() * players.length)
      if (!impostorIndices.includes(idx)) {
        impostorIndices.push(idx)
      }
    }
    
    const updatedPlayers = players.map((p, i) => ({
      ...p,
      isImpostor: impostorIndices.includes(i),
      hasSeenWord: false,
      votes: 0
    }))
    
    set({
      players: updatedPlayers,
      secretWord: word,
      currentPlayerIndex: 0,
      timeRemaining: get().timerDuration,
      screen: 'word-reveal'
    })
  },
  
  revealWord: () => {
    const { players, currentPlayerIndex } = get()
    const updatedPlayers = [...players]
    updatedPlayers[currentPlayerIndex] = {
      ...updatedPlayers[currentPlayerIndex],
      hasSeenWord: true
    }
    set({ players: updatedPlayers })
  },
  
  nextPlayer: () => {
    const { players, currentPlayerIndex } = get()
    if (currentPlayerIndex < players.length - 1) {
      set({ currentPlayerIndex: currentPlayerIndex + 1 })
    } else {
      set({ screen: 'timer' })
    }
  },
  
  setTimerDuration: (seconds) => set({ timerDuration: seconds, timeRemaining: seconds }),
  
  decrementTimer: () => {
    const { timeRemaining } = get()
    if (timeRemaining > 0) {
      set({ timeRemaining: timeRemaining - 1 })
    }
  },
  
  vote: (playerId) => {
    const { players } = get()
    const updatedPlayers = players.map(p => 
      p.id === playerId ? { ...p, votes: p.votes + 1 } : p
    )
    set({ players: updatedPlayers })
  },
  
  resetGame: () => set({
    screen: 'start',
    players: [],
    currentPlayerIndex: 0,
    secretWord: '',
    timeRemaining: 120,
    showHowToPlay: false
  }),
  
  toggleDarkMode: () => set(state => ({ isDarkMode: !state.isDarkMode })),
  
  setCategory: (categoryId) => set({ selectedCategory: categoryId }),
  
  setShowHowToPlay: (show) => set({ showHowToPlay: show })
}))
