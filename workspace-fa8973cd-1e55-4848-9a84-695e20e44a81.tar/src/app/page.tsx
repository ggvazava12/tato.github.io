'use client'

import { useState, useEffect, useRef, useCallback, useLayoutEffect } from 'react'
import { useGameStore } from '@/lib/game-store'
import { gameCategories, gameTexts } from '@/lib/game-data'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Slider } from '@/components/ui/slider'
import { Badge } from '@/components/ui/badge'
import { 
  Play, 
  Users, 
  Clock, 
  Eye, 
  Vote, 
  Skull, 
  CheckCircle,
  ChevronRight,
  Volume2,
  VolumeX,
  Moon,
  Sun,
  HelpCircle,
  Sparkles,
  Zap,
  Target
} from 'lucide-react'

// Use useLayoutEffect for client-side only effects to avoid hydration issues
const useIsomorphicLayoutEffect = typeof window !== 'undefined' ? useLayoutEffect : useEffect

// Sound effects using Web Audio API
const useSound = () => {
  const audioContextRef = useRef<AudioContext | null>(null)
  const [soundEnabled, setSoundEnabled] = useState(true)

  const getAudioContext = useCallback(() => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)()
    }
    return audioContextRef.current
  }, [])

  const playSound = useCallback((frequency: number, duration: number, type: OscillatorType = 'sine') => {
    if (!soundEnabled) return
    
    try {
      const ctx = getAudioContext()
      const oscillator = ctx.createOscillator()
      const gainNode = ctx.createGain()
      
      oscillator.connect(gainNode)
      gainNode.connect(ctx.destination)
      
      oscillator.frequency.value = frequency
      oscillator.type = type
      
      gainNode.gain.setValueAtTime(0.3, ctx.currentTime)
      gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration)
      
      oscillator.start(ctx.currentTime)
      oscillator.stop(ctx.currentTime + duration)
    } catch {
      // Audio not supported
    }
  }, [soundEnabled, getAudioContext])

  const playRevealSound = useCallback(() => {
    playSound(523.25, 0.15)
    setTimeout(() => playSound(659.25, 0.15), 100)
    setTimeout(() => playSound(783.99, 0.3), 200)
  }, [playSound])

  const playImpostorSound = useCallback(() => {
    playSound(200, 0.5, 'sawtooth')
    setTimeout(() => playSound(150, 0.5, 'sawtooth'), 200)
    setTimeout(() => playSound(100, 0.8, 'sawtooth'), 400)
  }, [playSound])

  const playClickSound = useCallback(() => {
    playSound(800, 0.05)
  }, [playSound])

  const playSuccessSound = useCallback(() => {
    playSound(523.25, 0.1)
    setTimeout(() => playSound(659.25, 0.1), 100)
    setTimeout(() => playSound(783.99, 0.2), 200)
    setTimeout(() => playSound(1046.50, 0.3), 300)
  }, [playSound])

  const playTickSound = useCallback(() => {
    playSound(1000, 0.02)
  }, [playSound])

  return { 
    soundEnabled, 
    setSoundEnabled, 
    playRevealSound, 
    playImpostorSound, 
    playClickSound,
    playSuccessSound,
    playTickSound
  }
}

// Animated background component
const AnimatedBackground = ({ isDarkMode }: { isDarkMode: boolean }) => (
  <div className="fixed inset-0 -z-10 overflow-hidden">
    <div className={`absolute inset-0 ${
      isDarkMode 
        ? 'bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900' 
        : 'bg-gradient-to-br from-purple-500 via-pink-500 to-orange-400'
    }`} />
    <div className={`absolute top-0 left-0 w-96 h-96 rounded-full blur-3xl animate-pulse ${
      isDarkMode ? 'bg-purple-600/30' : 'bg-yellow-300/40'
    }`} style={{ animationDuration: '4s' }} />
    <div className={`absolute bottom-0 right-0 w-96 h-96 rounded-full blur-3xl animate-pulse ${
      isDarkMode ? 'bg-pink-600/30' : 'bg-pink-300/40'
    }`} style={{ animationDuration: '4s', animationDelay: '2s' }} />
    <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full blur-3xl animate-pulse ${
      isDarkMode ? 'bg-blue-600/20' : 'bg-blue-300/30'
    }`} style={{ animationDuration: '6s', animationDelay: '1s' }} />
  </div>
)

// Start Screen Component
const StartScreen = () => {
  const { setScreen, isDarkMode, toggleDarkMode } = useGameStore()
  const { soundEnabled, setSoundEnabled, playClickSound } = useSound()
  const [mounted, setMounted] = useState(false)

  useIsomorphicLayoutEffect(() => {
    setMounted(true)
  }, [])

  const handleStart = () => {
    playClickSound()
    setScreen('setup')
  }

  const handleHowToPlay = () => {
    playClickSound()
    setScreen('how-to-play')
  }

  if (!mounted) return null

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 relative">
      {/* Logo and title */}
      <div className={`transform transition-all duration-1000 ${mounted ? 'translate-y-0 opacity-100' : '-translate-y-10 opacity-0'}`}>
        <div className="relative mb-8">
          <div className={`w-32 h-32 rounded-full flex items-center justify-center ${
            isDarkMode 
              ? 'bg-gradient-to-br from-purple-600 to-pink-600' 
              : 'bg-gradient-to-br from-yellow-400 to-orange-500'
          } shadow-2xl animate-bounce`} style={{ animationDuration: '3s' }}>
            <Skull className="w-16 h-16 text-white" />
          </div>
          <div className="absolute -top-2 -right-2 w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center animate-ping">
            <Sparkles className="w-4 h-4 text-yellow-800" />
          </div>
        </div>
        
        <h1 className={`text-5xl md:text-7xl font-black text-center mb-4 ${
          isDarkMode ? 'text-white' : 'text-white'
        } drop-shadow-lg`}>
          {gameTexts.start.title}
        </h1>
        
        <p className={`text-xl md:text-2xl text-center mb-12 ${
          isDarkMode ? 'text-purple-200' : 'text-white/90'
        }`}>
          {gameTexts.start.subtitle}
        </p>
      </div>

      {/* Buttons */}
      <div className={`flex flex-col gap-4 w-full max-w-sm transform transition-all duration-1000 delay-300 ${mounted ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
        <Button 
          onClick={handleStart}
          className={`h-16 text-xl font-bold rounded-2xl shadow-xl hover:scale-105 transition-all ${
            isDarkMode 
              ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500' 
              : 'bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-300 hover:to-orange-400'
          } text-white`}
        >
          <Play className="w-6 h-6 mr-2" />
          {gameTexts.start.startButton}
        </Button>
        
        <Button 
          onClick={handleHowToPlay}
          variant="outline"
          className={`h-14 text-lg font-semibold rounded-2xl backdrop-blur-sm ${
            isDarkMode 
              ? 'bg-white/10 border-white/30 text-white hover:bg-white/20' 
              : 'bg-white/20 border-white/50 text-white hover:bg-white/30'
          }`}
        >
          <HelpCircle className="w-5 h-5 mr-2" />
          {gameTexts.start.howToPlay}
        </Button>
      </div>

      {/* Settings */}
      <div className={`absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-4 transform transition-all duration-1000 delay-500 ${mounted ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
        <Button
          onClick={() => setSoundEnabled(!soundEnabled)}
          variant="ghost"
          className={`rounded-full w-12 h-12 ${isDarkMode ? 'text-white/70 hover:text-white hover:bg-white/10' : 'text-white/80 hover:text-white hover:bg-white/20'}`}
        >
          {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
        </Button>
        <Button
          onClick={() => {
            playClickSound()
            toggleDarkMode()
          }}
          variant="ghost"
          className={`rounded-full w-12 h-12 ${isDarkMode ? 'text-white/70 hover:text-white hover:bg-white/10' : 'text-white/80 hover:text-white hover:bg-white/20'}`}
        >
          {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </Button>
      </div>
    </div>
  )
}

// How to Play Screen
const HowToPlayScreen = () => {
  const { setScreen, isDarkMode } = useGameStore()
  const { playClickSound } = useSound()

  const steps = [
    { icon: Eye, title: gameTexts.howToPlay.step1, desc: gameTexts.howToPlay.step1Desc },
    { icon: Sparkles, title: gameTexts.howToPlay.step2, desc: gameTexts.howToPlay.step2Desc },
    { icon: Target, title: gameTexts.howToPlay.step3, desc: gameTexts.howToPlay.step3Desc },
    { icon: Vote, title: gameTexts.howToPlay.step4, desc: gameTexts.howToPlay.step4Desc },
  ]

  return (
    <div className="min-h-screen flex flex-col p-6 relative">
      <div className="flex-1 flex flex-col items-center justify-center max-w-md mx-auto">
        <h1 className={`text-3xl md:text-4xl font-bold text-center mb-8 ${
          isDarkMode ? 'text-white' : 'text-white'
        }`}>
          {gameTexts.howToPlay.title}
        </h1>

        <div className="space-y-4 w-full">
          {steps.map((step, index) => (
            <Card 
              key={index}
              className={`backdrop-blur-xl ${
                isDarkMode 
                  ? 'bg-white/10 border-white/20' 
                  : 'bg-white/20 border-white/40'
              } rounded-2xl overflow-hidden`}
            >
              <CardContent className="p-4 flex items-start gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                  isDarkMode ? 'bg-purple-500/50' : 'bg-white/50'
                }`}>
                  <step.icon className={`w-6 h-6 ${isDarkMode ? 'text-white' : 'text-purple-700'}`} />
                </div>
                <div>
                  <h3 className={`font-semibold mb-1 ${isDarkMode ? 'text-white' : 'text-white'}`}>
                    {index + 1}. {step.title}
                  </h3>
                  <p className={`text-sm ${isDarkMode ? 'text-purple-200' : 'text-white/80'}`}>
                    {step.desc}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Button 
          onClick={() => {
            playClickSound()
            setScreen('start')
          }}
          className={`mt-8 h-14 px-8 text-lg font-semibold rounded-2xl ${
            isDarkMode 
              ? 'bg-gradient-to-r from-purple-600 to-pink-600' 
              : 'bg-gradient-to-r from-yellow-400 to-orange-500'
          } text-white`}
        >
          {gameTexts.howToPlay.gotIt}
        </Button>
      </div>
    </div>
  )
}

// Setup Screen Component
const SetupScreen = () => {
  const { 
    setScreen, 
    setPlayers, 
    setTimerDuration, 
    startGame, 
    setCategory,
    selectedCategory,
    timerDuration,
    isDarkMode 
  } = useGameStore()
  const { playClickSound, playSuccessSound } = useSound()
  
  const [playerCount, setPlayerCount] = useState(4)
  const [impostorCount, setImpostorCount] = useState(1)
  const [mounted, setMounted] = useState(false)

  useIsomorphicLayoutEffect(() => {
    setMounted(true)
  }, [])

  const handleStart = () => {
    playSuccessSound()
    setPlayers(playerCount)
    startGame(gameCategories)
  }

  const maxImpostors = Math.min(3, Math.floor(playerCount / 2))

  return (
    <div className="min-h-screen flex flex-col p-6 relative">
      <div className={`flex-1 flex flex-col max-w-md mx-auto w-full transform transition-all duration-500 ${mounted ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
        {/* Header */}
        <div className="text-center mb-8 mt-8">
          <h1 className={`text-3xl md:text-4xl font-bold mb-2 ${isDarkMode ? 'text-white' : 'text-white'}`}>
            {gameTexts.setup.title}
          </h1>
        </div>

        {/* Settings Cards */}
        <div className="space-y-4 flex-1">
          {/* Player Count */}
          <Card className={`backdrop-blur-xl ${
            isDarkMode ? 'bg-white/10 border-white/20' : 'bg-white/20 border-white/40'
          } rounded-2xl`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    isDarkMode ? 'bg-purple-500/50' : 'bg-white/50'
                  }`}>
                    <Users className={`w-5 h-5 ${isDarkMode ? 'text-white' : 'text-purple-700'}`} />
                  </div>
                  <span className={`font-semibold ${isDarkMode ? 'text-white' : 'text-white'}`}>
                    {gameTexts.setup.playerCount}
                  </span>
                </div>
                <Badge className={`text-lg font-bold px-4 py-2 ${
                  isDarkMode ? 'bg-purple-500' : 'bg-white/50 text-purple-700'
                }`}>
                  {playerCount}
                </Badge>
              </div>
              <Slider 
                value={[playerCount]} 
                onValueChange={([value]) => setPlayerCount(value)}
                min={3} 
                max={12} 
                step={1}
                className="w-full"
              />
              <div className={`flex justify-between text-sm mt-2 ${isDarkMode ? 'text-purple-200' : 'text-white/70'}`}>
                <span>3</span>
                <span>12</span>
              </div>
            </CardContent>
          </Card>

          {/* Impostor Count */}
          <Card className={`backdrop-blur-xl ${
            isDarkMode ? 'bg-white/10 border-white/20' : 'bg-white/20 border-white/40'
          } rounded-2xl`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    isDarkMode ? 'bg-pink-500/50' : 'bg-white/50'
                  }`}>
                    <Skull className={`w-5 h-5 ${isDarkMode ? 'text-white' : 'text-pink-700'}`} />
                  </div>
                  <span className={`font-semibold ${isDarkMode ? 'text-white' : 'text-white'}`}>
                    {gameTexts.setup.impostorCount}
                  </span>
                </div>
                <Badge className={`text-lg font-bold px-4 py-2 ${
                  isDarkMode ? 'bg-pink-500' : 'bg-white/50 text-pink-700'
                }`}>
                  {impostorCount}
                </Badge>
              </div>
              <Slider 
                value={[impostorCount]} 
                onValueChange={([value]) => setImpostorCount(value)}
                min={1} 
                max={maxImpostors} 
                step={1}
                className="w-full"
              />
              <div className={`flex justify-between text-sm mt-2 ${isDarkMode ? 'text-purple-200' : 'text-white/70'}`}>
                <span>1</span>
                <span>{maxImpostors}</span>
              </div>
            </CardContent>
          </Card>

          {/* Timer */}
          <Card className={`backdrop-blur-xl ${
            isDarkMode ? 'bg-white/10 border-white/20' : 'bg-white/20 border-white/40'
          } rounded-2xl`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    isDarkMode ? 'bg-blue-500/50' : 'bg-white/50'
                  }`}>
                    <Clock className={`w-5 h-5 ${isDarkMode ? 'text-white' : 'text-blue-700'}`} />
                  </div>
                  <span className={`font-semibold ${isDarkMode ? 'text-white' : 'text-white'}`}>
                    {gameTexts.setup.timerDuration}
                  </span>
                </div>
                <Badge className={`text-lg font-bold px-4 py-2 ${
                  isDarkMode ? 'bg-blue-500' : 'bg-white/50 text-blue-700'
                }`}>
                  {timerDuration} წამი
                </Badge>
              </div>
              <Slider 
                value={[timerDuration]} 
                onValueChange={([value]) => setTimerDuration(value)}
                min={60} 
                max={300} 
                step={30}
                className="w-full"
              />
              <div className={`flex justify-between text-sm mt-2 ${isDarkMode ? 'text-purple-200' : 'text-white/70'}`}>
                <span>1 {gameTexts.setup.minutes}</span>
                <span>5 {gameTexts.setup.minutes}</span>
              </div>
            </CardContent>
          </Card>

          {/* Category Selection */}
          <Card className={`backdrop-blur-xl ${
            isDarkMode ? 'bg-white/10 border-white/20' : 'bg-white/20 border-white/40'
          } rounded-2xl`}>
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  isDarkMode ? 'bg-orange-500/50' : 'bg-white/50'
                }`}>
                  <Sparkles className={`w-5 h-5 ${isDarkMode ? 'text-white' : 'text-orange-700'}`} />
                </div>
                <span className={`font-semibold ${isDarkMode ? 'text-white' : 'text-white'}`}>
                  {gameTexts.setup.category}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  onClick={() => setCategory('all')}
                  variant={selectedCategory === 'all' ? 'default' : 'outline'}
                  className={`h-10 rounded-xl text-sm ${
                    selectedCategory === 'all' 
                      ? isDarkMode 
                        ? 'bg-purple-500 hover:bg-purple-400' 
                        : 'bg-yellow-400 hover:bg-yellow-300 text-purple-900'
                      : isDarkMode
                        ? 'bg-white/10 border-white/30 text-white hover:bg-white/20'
                        : 'bg-white/20 border-white/50 text-white hover:bg-white/30'
                  }`}
                >
                  {gameTexts.setup.allCategories}
                </Button>
                {gameCategories.map(cat => (
                  <Button
                    key={cat.id}
                    onClick={() => setCategory(cat.id)}
                    variant={selectedCategory === cat.id ? 'default' : 'outline'}
                    className={`h-10 rounded-xl text-sm ${
                      selectedCategory === cat.id 
                        ? isDarkMode 
                          ? 'bg-purple-500 hover:bg-purple-400' 
                          : 'bg-yellow-400 hover:bg-yellow-300 text-purple-900'
                        : isDarkMode
                          ? 'bg-white/10 border-white/30 text-white hover:bg-white/20'
                          : 'bg-white/20 border-white/50 text-white hover:bg-white/30'
                    }`}
                  >
                    {cat.name}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Buttons */}
        <div className="flex gap-4 mt-6 mb-8">
          <Button 
            onClick={() => {
              playClickSound()
              setScreen('start')
            }}
            variant="outline"
            className={`flex-1 h-14 text-lg font-semibold rounded-2xl backdrop-blur-sm ${
              isDarkMode 
                ? 'bg-white/10 border-white/30 text-white hover:bg-white/20' 
                : 'bg-white/20 border-white/50 text-white hover:bg-white/30'
            }`}
          >
            {gameTexts.setup.back}
          </Button>
          <Button 
            onClick={handleStart}
            className={`flex-1 h-14 text-lg font-bold rounded-2xl ${
              isDarkMode 
                ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500' 
                : 'bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-300 hover:to-orange-400'
            } text-white`}
          >
            {gameTexts.setup.startGame}
            <ChevronRight className="w-5 h-5 ml-1" />
          </Button>
        </div>
      </div>
    </div>
  )
}

// Word Reveal Screen Component
const WordRevealScreen = () => {
  const { 
    players, 
    currentPlayerIndex, 
    secretWord, 
    revealWord, 
    nextPlayer, 
    isDarkMode 
  } = useGameStore()
  const { playRevealSound, playImpostorSound, playClickSound } = useSound()
  
  const [showWord, setShowWord] = useState(false)
  const [isRevealing, setIsRevealing] = useState(false)
  const [mounted, setMounted] = useState(false)

  const currentPlayer = players[currentPlayerIndex]
  const isImpostor = currentPlayer?.isImpostor

  useIsomorphicLayoutEffect(() => {
    setMounted(true)
    setShowWord(false)
  }, [currentPlayerIndex])

  const handleReveal = () => {
    setIsRevealing(true)
    setTimeout(() => {
      setShowWord(true)
      revealWord()
      if (isImpostor) {
        playImpostorSound()
      } else {
        playRevealSound()
      }
      setIsRevealing(false)
      // Vibrate if supported
      if (navigator.vibrate) {
        navigator.vibrate(100)
      }
    }, 600)
  }

  const handleContinue = () => {
    playClickSound()
    setShowWord(false)
    setTimeout(() => {
      nextPlayer()
    }, 300)
  }

  if (!currentPlayer) return null

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 relative">
      <div className={`w-full max-w-sm transform transition-all duration-500 ${mounted ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
        {/* Progress */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {players.map((_, i) => (
            <div 
              key={i} 
              className={`w-3 h-3 rounded-full transition-all ${
                i < currentPlayerIndex 
                  ? 'bg-green-500' 
                  : i === currentPlayerIndex 
                    ? isDarkMode ? 'bg-purple-400 scale-125' : 'bg-yellow-400 scale-125'
                    : isDarkMode ? 'bg-white/30' : 'bg-white/50'
              }`} 
            />
          ))}
        </div>

        {/* Player Info */}
        <div className="text-center mb-8">
          <p className={`text-lg mb-2 ${isDarkMode ? 'text-purple-200' : 'text-white/80'}`}>
            {gameTexts.wordReveal.playerTurn}
          </p>
          <h2 className={`text-3xl font-bold ${isDarkMode ? 'text-white' : 'text-white'}`}>
            {currentPlayer.name}
          </h2>
        </div>

        {/* Card */}
        <div 
          className={`relative aspect-[3/4] mb-8 cursor-pointer transition-all duration-500 ${
            isRevealing ? 'scale-95' : 'scale-100'
          }`}
          onClick={!showWord ? handleReveal : undefined}
          style={{ perspective: '1000px' }}
        >
          <div 
            className={`absolute inset-0 rounded-3xl shadow-2xl transition-all duration-500 ${
              showWord 
                ? '' 
                : 'hover:scale-105 hover:shadow-3xl'
            }`}
            style={{ 
              transformStyle: 'preserve-3d',
              transform: showWord ? 'rotateY(180deg)' : 'rotateY(0deg)'
            }}
          >
            {/* Front of card */}
            <div 
              className={`absolute inset-0 rounded-3xl flex flex-col items-center justify-center backface-hidden ${
                isDarkMode 
                  ? 'bg-gradient-to-br from-purple-600 to-pink-600' 
                  : 'bg-gradient-to-br from-yellow-400 to-orange-500'
              }`}
              style={{ backfaceVisibility: 'hidden' }}
            >
              <div className="w-20 h-20 rounded-full bg-white/20 flex items-center justify-center mb-4 animate-pulse">
                <Eye className="w-10 h-10 text-white" />
              </div>
              <p className="text-white text-xl font-semibold text-center px-4">
                დააჭირე სიტყვის სანახავად
              </p>
            </div>

            {/* Back of card */}
            <div 
              className={`absolute inset-0 rounded-3xl flex flex-col items-center justify-center p-6 ${
                isImpostor 
                  ? 'bg-gradient-to-br from-red-600 to-orange-600' 
                  : isDarkMode
                    ? 'bg-gradient-to-br from-green-500 to-teal-600'
                    : 'bg-gradient-to-br from-green-400 to-teal-500'
              }`}
              style={{ 
                backfaceVisibility: 'hidden',
                transform: 'rotateY(180deg)'
              }}
            >
              {isImpostor ? (
                <>
                  <div className="w-20 h-20 rounded-full bg-white/20 flex items-center justify-center mb-4 animate-bounce">
                    <Skull className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-white text-2xl font-bold text-center mb-2">
                    {gameTexts.wordReveal.youAreImpostor}
                  </h3>
                  <p className="text-white/80 text-center">
                    {gameTexts.wordReveal.impostorHint}
                  </p>
                </>
              ) : (
                <>
                  <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center mb-4">
                    <Sparkles className="w-8 h-8 text-white" />
                  </div>
                  <p className="text-white/80 text-lg mb-2">
                    {gameTexts.wordReveal.yourWord}
                  </p>
                  <h3 className="text-white text-3xl font-bold text-center">
                    {secretWord}
                  </h3>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Button */}
        {showWord && (
          <Button 
            onClick={handleContinue}
            className={`w-full h-14 text-lg font-bold rounded-2xl animate-in fade-in slide-in-from-bottom-4 ${
              isDarkMode 
                ? 'bg-gradient-to-r from-purple-600 to-pink-600' 
                : 'bg-gradient-to-r from-yellow-400 to-orange-500'
            } text-white`}
          >
            {currentPlayerIndex < players.length - 1 
              ? gameTexts.wordReveal.nextPlayer 
              : gameTexts.wordReveal.startDiscussion}
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        )}
      </div>
    </div>
  )
}

// Timer Screen Component
const TimerScreen = () => {
  const { timeRemaining, decrementTimer, setScreen, timerDuration, isDarkMode } = useGameStore()
  const { playClickSound, playTickSound, playSuccessSound } = useSound()
  const [mounted, setMounted] = useState(false)

  useIsomorphicLayoutEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (timeRemaining <= 0) {
      playSuccessSound()
      setScreen('voting')
      return
    }

    const interval = setInterval(() => {
      decrementTimer()
      if (timeRemaining <= 10 && timeRemaining > 0) {
        playTickSound()
      }
    }, 1000)

    return () => clearInterval(interval)
  }, [timeRemaining, decrementTimer, setScreen, playTickSound, playSuccessSound])

  const minutes = Math.floor(timeRemaining / 60)
  const seconds = timeRemaining % 60
  const progress = (timeRemaining / timerDuration) * 100

  const handleSkip = () => {
    playClickSound()
    setScreen('voting')
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 relative">
      <div className={`w-full max-w-sm transform transition-all duration-500 ${mounted ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
        {/* Title */}
        <h1 className={`text-3xl md:text-4xl font-bold text-center mb-4 ${isDarkMode ? 'text-white' : 'text-white'}`}>
          {gameTexts.timer.title}
        </h1>
        <p className={`text-xl text-center mb-12 ${isDarkMode ? 'text-purple-200' : 'text-white/80'}`}>
          {gameTexts.timer.findImpostor}
        </p>

        {/* Timer Circle */}
        <div className="relative w-64 h-64 mx-auto mb-12">
          <svg className="w-full h-full transform -rotate-90">
            <circle
              cx="128"
              cy="128"
              r="120"
              fill="none"
              stroke={isDarkMode ? 'rgba(255,255,255,0.1)' : 'rgba(255,255,255,0.2)'}
              strokeWidth="12"
            />
            <circle
              cx="128"
              cy="128"
              r="120"
              fill="none"
              stroke={timeRemaining <= 10 ? '#ef4444' : isDarkMode ? '#a855f7' : '#fbbf24'}
              strokeWidth="12"
              strokeLinecap="round"
              strokeDasharray={2 * Math.PI * 120}
              strokeDashoffset={2 * Math.PI * 120 * (1 - progress / 100)}
              className="transition-all duration-1000"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className={`text-6xl font-bold ${isDarkMode ? 'text-white' : 'text-white'}`}>
              {minutes}:{seconds.toString().padStart(2, '0')}
            </span>
            <span className={`text-lg ${isDarkMode ? 'text-purple-200' : 'text-white/70'}`}>
              {gameTexts.timer.timeRemaining}
            </span>
          </div>
        </div>

        {/* Warning */}
        {timeRemaining <= 10 && (
          <div className="text-center mb-8 animate-pulse">
            <Zap className="w-12 h-12 text-red-500 mx-auto mb-2" />
            <p className="text-red-400 font-semibold">დრო ახლოვდება!</p>
          </div>
        )}

        {/* Skip Button */}
        <Button 
          onClick={handleSkip}
          variant="outline"
          className={`w-full h-14 text-lg font-semibold rounded-2xl backdrop-blur-sm ${
            isDarkMode 
              ? 'bg-white/10 border-white/30 text-white hover:bg-white/20' 
              : 'bg-white/20 border-white/50 text-white hover:bg-white/30'
          }`}
        >
          {gameTexts.timer.startVoting}
          <ChevronRight className="w-5 h-5 ml-2" />
        </Button>
      </div>
    </div>
  )
}

// Voting Screen Component
const VotingScreen = () => {
  const { players, vote, setScreen, isDarkMode } = useGameStore()
  const { playClickSound, playSuccessSound } = useSound()
  
  const [currentVoter, setCurrentVoter] = useState(0)
  const [votes, setVotes] = useState<Record<number, number>>({})
  const [selectedPlayer, setSelectedPlayer] = useState<number | null>(null)
  const [mounted, setMounted] = useState(false)

  useIsomorphicLayoutEffect(() => {
    setMounted(true)
  }, [])

  const handleVote = (playerId: number) => {
    setSelectedPlayer(playerId)
  }

  const confirmVote = () => {
    if (selectedPlayer === null) return
    
    playClickSound()
    const newVotes = { ...votes, [currentVoter]: selectedPlayer }
    setVotes(newVotes)
    vote(selectedPlayer)
    setSelectedPlayer(null)

    if (currentVoter < players.length - 1) {
      setCurrentVoter(currentVoter + 1)
    } else {
      playSuccessSound()
      setScreen('results')
    }
  }

  const currentPlayerVoting = players[currentVoter]

  return (
    <div className="min-h-screen flex flex-col p-6 relative">
      <div className={`flex-1 flex flex-col max-w-md mx-auto w-full transform transition-all duration-500 ${mounted ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
        {/* Header */}
        <div className="text-center mb-6 mt-4">
          <h1 className={`text-3xl font-bold mb-2 ${isDarkMode ? 'text-white' : 'text-white'}`}>
            {gameTexts.voting.title}
          </h1>
          <p className={`text-lg ${isDarkMode ? 'text-purple-200' : 'text-white/80'}`}>
            {gameTexts.voting.currentPlayer} <strong>{currentPlayerVoting?.name}</strong>
          </p>
        </div>

        {/* Progress */}
        <div className="flex items-center justify-center gap-2 mb-6">
          {players.map((_, i) => (
            <div 
              key={i} 
              className={`w-3 h-3 rounded-full transition-all ${
                i < currentVoter 
                  ? 'bg-green-500' 
                  : i === currentVoter 
                    ? isDarkMode ? 'bg-purple-400 scale-125' : 'bg-yellow-400 scale-125'
                    : isDarkMode ? 'bg-white/30' : 'bg-white/50'
              }`} 
            />
          ))}
        </div>

        {/* Question */}
        <p className={`text-xl text-center mb-6 ${isDarkMode ? 'text-purple-200' : 'text-white/90'}`}>
          {gameTexts.voting.question}
        </p>

        {/* Players to vote for */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {players.map((player) => (
            <Button
              key={player.id}
              onClick={() => handleVote(player.id)}
              variant={selectedPlayer === player.id ? 'default' : 'outline'}
              className={`h-16 rounded-2xl font-semibold ${
                selectedPlayer === player.id 
                  ? isDarkMode 
                    ? 'bg-purple-500 hover:bg-purple-400 ring-2 ring-white' 
                    : 'bg-yellow-400 hover:bg-yellow-300 text-purple-900 ring-2 ring-white'
                  : isDarkMode
                    ? 'bg-white/10 border-white/30 text-white hover:bg-white/20'
                    : 'bg-white/20 border-white/50 text-white hover:bg-white/30'
              }`}
            >
              {player.name}
            </Button>
          ))}
        </div>

        {/* Vote Button */}
        <Button 
          onClick={confirmVote}
          disabled={selectedPlayer === null}
          className={`w-full h-14 text-lg font-bold rounded-2xl ${
            selectedPlayer === null
              ? 'bg-gray-400 cursor-not-allowed'
              : isDarkMode 
                ? 'bg-gradient-to-r from-purple-600 to-pink-600' 
                : 'bg-gradient-to-r from-yellow-400 to-orange-500'
          } text-white`}
        >
          {gameTexts.voting.voteFor}
          <ChevronRight className="w-5 h-5 ml-2" />
        </Button>
      </div>
    </div>
  )
}

// Results Screen Component
const ResultsScreen = () => {
  const { players, secretWord, resetGame, setScreen, isDarkMode } = useGameStore()
  const { playImpostorSound, playSuccessSound, playClickSound } = useSound()
  
  const [showResults, setShowResults] = useState(false)
  const [showWord, setShowWord] = useState(false)
  const [mounted, setMounted] = useState(false)

  const impostors = players.filter(p => p.isImpostor)
  const maxVotes = Math.max(...players.map(p => p.votes))
  const mostVotedPlayers = players.filter(p => p.votes === maxVotes)
  const impostorsFound = mostVotedPlayers.some(p => p.isImpostor)

  useIsomorphicLayoutEffect(() => {
    setMounted(true)
    const timer1 = setTimeout(() => {
      setShowResults(true)
      playImpostorSound()
    }, 500)
    const timer2 = setTimeout(() => {
      setShowWord(true)
      playSuccessSound()
    }, 1500)
    return () => {
      clearTimeout(timer1)
      clearTimeout(timer2)
    }
  }, [playImpostorSound, playSuccessSound])

  const handlePlayAgain = () => {
    playClickSound()
    resetGame()
    setScreen('setup')
  }

  const handleMainMenu = () => {
    playClickSound()
    resetGame()
    setScreen('start')
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 relative">
      <div className={`w-full max-w-sm transform transition-all duration-500 ${mounted ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
        {/* Result Banner */}
        <div className={`text-center mb-8 transform transition-all duration-500 ${showResults ? 'scale-100 opacity-100' : 'scale-75 opacity-0'}`}>
          <div className={`w-24 h-24 rounded-full mx-auto mb-4 flex items-center justify-center ${
            impostorsFound 
              ? 'bg-gradient-to-br from-green-500 to-teal-600' 
              : 'bg-gradient-to-br from-red-500 to-orange-600'
          }`}>
            {impostorsFound ? (
              <CheckCircle className="w-12 h-12 text-white" />
            ) : (
              <Skull className="w-12 h-12 text-white" />
            )}
          </div>
          <h1 className={`text-3xl font-bold mb-2 ${isDarkMode ? 'text-white' : 'text-white'}`}>
            {impostorsFound ? gameTexts.results.winner : gameTexts.results.playersFailed}
          </h1>
        </div>

        {/* Impostor Reveal */}
        <div className={`mb-8 transform transition-all duration-500 ${showResults ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'}`}>
          <Card className={`backdrop-blur-xl overflow-hidden ${
            isDarkMode ? 'bg-white/10 border-white/20' : 'bg-white/20 border-white/40'
          } rounded-2xl`}>
            <CardContent className="p-6 text-center">
              <p className={`text-lg mb-2 ${isDarkMode ? 'text-purple-200' : 'text-white/80'}`}>
                {gameTexts.results.impostorWas}
              </p>
              <div className="flex flex-wrap justify-center gap-2">
                {impostors.map((imp) => (
                  <Badge 
                    key={imp.id}
                    className="text-lg px-4 py-2 bg-gradient-to-r from-red-500 to-orange-500 text-white"
                  >
                    <Skull className="w-4 h-4 mr-2" />
                    {imp.name}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Secret Word Reveal */}
        <div className={`mb-8 transform transition-all duration-500 ${showWord ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'}`}>
          <Card className={`backdrop-blur-xl ${
            isDarkMode ? 'bg-white/10 border-white/20' : 'bg-white/20 border-white/40'
          } rounded-2xl`}>
            <CardContent className="p-6 text-center">
              <p className={`text-lg mb-2 ${isDarkMode ? 'text-purple-200' : 'text-white/80'}`}>
                {gameTexts.results.theWordWas}
              </p>
              <h2 className={`text-3xl font-bold ${isDarkMode ? 'text-white' : 'text-white'}`}>
                {secretWord}
              </h2>
            </CardContent>
          </Card>
        </div>

        {/* Vote Results */}
        <div className={`mb-8 transform transition-all duration-500 ${showWord ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'}`}>
          <Card className={`backdrop-blur-xl ${
            isDarkMode ? 'bg-white/10 border-white/20' : 'bg-white/20 border-white/40'
          } rounded-2xl`}>
            <CardContent className="p-4">
              <h3 className={`text-lg font-semibold mb-3 text-center ${isDarkMode ? 'text-white' : 'text-white'}`}>
                ხმები
              </h3>
              <div className="space-y-2">
                {players.map(player => (
                  <div key={player.id} className="flex items-center justify-between">
                    <span className={`${isDarkMode ? 'text-white' : 'text-white'} ${player.isImpostor ? 'text-red-400' : ''}`}>
                      {player.name}
                      {player.isImpostor && <Skull className="w-4 h-4 inline ml-1" />}
                    </span>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: player.votes }).map((_, i) => (
                        <div key={i} className="w-2 h-2 rounded-full bg-yellow-400" />
                      ))}
                      <span className={`ml-2 ${isDarkMode ? 'text-purple-200' : 'text-white/70'}`}>
                        {player.votes}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Buttons */}
        <div className="flex gap-4">
          <Button 
            onClick={handleMainMenu}
            variant="outline"
            className={`flex-1 h-14 text-lg font-semibold rounded-2xl backdrop-blur-sm ${
              isDarkMode 
                ? 'bg-white/10 border-white/30 text-white hover:bg-white/20' 
                : 'bg-white/20 border-white/50 text-white hover:bg-white/30'
            }`}
          >
            {gameTexts.results.mainMenu}
          </Button>
          <Button 
            onClick={handlePlayAgain}
            className={`flex-1 h-14 text-lg font-bold rounded-2xl ${
              isDarkMode 
                ? 'bg-gradient-to-r from-purple-600 to-pink-600' 
                : 'bg-gradient-to-r from-yellow-400 to-orange-500'
            } text-white`}
          >
            {gameTexts.results.playAgain}
          </Button>
        </div>
      </div>
    </div>
  )
}

// Main App Component
export default function ImpostorGame() {
  const { screen, isDarkMode } = useGameStore()

  return (
    <div className={`min-h-screen ${isDarkMode ? 'text-white' : 'text-white'}`}>
      <AnimatedBackground isDarkMode={isDarkMode} />
      
      <main className="relative z-10">
        {screen === 'start' && <StartScreen />}
        {screen === 'how-to-play' && <HowToPlayScreen />}
        {screen === 'setup' && <SetupScreen />}
        {screen === 'word-reveal' && <WordRevealScreen />}
        {screen === 'timer' && <TimerScreen />}
        {screen === 'voting' && <VotingScreen />}
        {screen === 'results' && <ResultsScreen />}
      </main>
    </div>
  )
}
