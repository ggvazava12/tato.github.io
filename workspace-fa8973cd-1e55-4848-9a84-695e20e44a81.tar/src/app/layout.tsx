import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "იმპოსტორი - სოციალური თამაში",
  description: "გამოაშკარავე საიდუმლო მოთამაშე! სახალისო სოციალური თამაში მეგობრებთან ერთად.",
  keywords: ["იმპოსტორი", "თამაში", "სოციალური თამაში", "პარტი თამაში", "ქართული თამაში"],
  authors: [{ name: "Impostor Game" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "იმპოსტორი - სოციალური თამაში",
    description: "გამოაშკარავე საიდუმლო მოთამაშე!",
    type: "website",
  },
  viewport: {
    width: "device-width",
    initialScale: 1,
    maximumScale: 1,
    userScalable: false,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ka" suppressHydrationWarning>
      <head>
        <meta charSet="utf-8" />
        <meta name="theme-color" content="#9333ea" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground overflow-x-hidden`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
